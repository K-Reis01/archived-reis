class Quest:
    def __init__(self, a, b, c, d):
        self.a = a
        self.b = b
        self.c = c
        self.d = d


class See:
    def __init__(self, a1, a2, a3, a4):
        self.a1 = a1
        self.a2 = a2
        self.a3 = a3
        self.a4 = a4


class Perguntas:
    def __init__(self, pergunta):
        self.pergunta = pergunta


# ALTERNATIVAS DAS PERGUNTAS
quest1 = Quest('a','b','c','d')
quest2 = Quest('a','b','c','d')
quest3 = Quest('a','b','c','d')
quest4 = Quest('a','b','c','d')
quest5 = Quest('a','b','c','d')
quest6 = Quest('a','b','c','d')
quest7 = Quest('a','b','c','d')
quest8 = Quest('a','b','c','d')
quest9 = Quest('a','b','c','d')
quest10 = Quest('a','b','c','d')
quest11 = Quest('a','b','c','d')
quest12 = Quest('a','b','c','d')
quest13 = Quest('a','b','c','d')
quest14 = Quest('a','b','c','d')
quest15 = Quest('a','b','c','d')
quest16 = Quest('a','b','c','d')
quest17 = Quest('a','b','c','d')
quest18 = Quest('a','b','c','d')
quest19 = Quest('a','b','c','d')
quest20 = Quest('a','b','c','d')
quest21 = Quest('a','b','c','d')
quest22 = Quest('a','b','c','d')
quest23 = Quest('a','b','c','d')
quest24 = Quest('a','b','c','d')
quest25 = Quest('a','b','c','d')
quest26 = Quest('a','b','c','d')
quest27 = Quest('a','b','c','d')
quest28 = Quest('a','b','c','d')
quest29 = Quest('a','b','c','d')
quest30 = Quest('a','b','c','d')

q1 = See('preto, amarelo e vermelho','branco, azul, verde e rosa','branco, azul, verde e amarelo', 'branco, azul, dourado, verde')
q2 = See('New York','Los Angeles','Nevada','Washington')
q3 = See('Os Simpsons','Bob Esponja','Procurando o Nemo','Futurama')
q4 = See('Ordem e Progresso','Independecia ou Morte','Mãe tem café?','Independencia a Patria Amada')
q5 = See('Apollo 11','Sputnik 1','Starship','Vostok 1')
q6 = See('Cantor Norte Americano','Poeta Europeu','Mafioso Italiano','Presidente do brasil')
q7 = See('2020','2019','2021','2024')
q8 = See('Family Guy','Todo Mundo em Panico','The Walking Dead','Gotham')
q9 = See('2,0132','3,14','3,85','0,11')
q10 = See('Mitologia Grega','Mitologia Nordica','Mitologia Brasileira','Mitologia Egipicia')
q11 = See('1990', '2000', '1994', '1999')
q12 = See('Argentina', 'Brasil', 'Peru', 'Colômbia')
q13 = See('Isabel Allende', 'Gabriel García Márquez', 'Jorge Amado', 'Pablo Neruda')
q14 = See('KCl', 'NaOH', 'CaCO3', 'NaCl')
q15 = See('Estados Unidos', 'Nova Zelândia', 'Alemanha', 'França')
q16 = See('Copenhague', 'Helsinque', 'Estocolmo', 'Oslo')
q17 = See('Gregor Mendel', 'Louis Pasteur', 'Charles Darwin', 'James Watson')
q18 = See('Chile', 'Equador', 'Peru', 'Bolívia')
q19 = See('Newton', 'Watt', 'Joule', 'Hertz')
q20 = See('Claude Monet', 'Michelangelo', 'Vincent van Gogh', 'Pablo Picasso')
q21 = See('Ártico', 'Atlântico', 'Pacífico', 'Índico')
q22 = See('George Washington', 'Thomas Jefferson', 'James Madison', 'John Adams')
q23 = See('1985', '1989', '1980', '1991')
q24 = See('China', 'Estados Unidos', 'Índia', 'Indonésia')
q25 = See('Ben Jonson', 'William Shakespeare', 'Christopher Marlowe', 'Thomas Kyd')
q26 = See('Terra', 'Saturno', 'Júpiter', 'Marte')
q27 = See('Francês', 'Italiano', 'Inglês', 'Árabe',)
q28 = See('Nikola Tesla', 'Thomas Edison', 'Alexander Graham Bell', 'Benjamin Franklin')
q29 = See('América do Sul', 'Europa', 'Ásia', 'África')
q30 = See('Montreal', 'Ottawa', 'Vancouver', 'Toronto')


# FUNÇÃO PARA EXIBIR AS PERGUNTAS

pergunta1 = Perguntas('Quais cores presentes na bandeira do Brasil?\n')
pergunta2 = Perguntas('Qual a capital dos Estados Unidos?\n')
pergunta3 = Perguntas('Em qual desenho animado o personagem principal\ntem como melhor amigo uma estrela do mar?\n')
pergunta4 = Perguntas('O que Dom Pedro I gritou as margens do rio Ipiranga?\n')
pergunta5 = Perguntas('Qual nome da primeira nave espacial tripulada a pousar na lua?\n')
pergunta6 = Perguntas('Juscelino Kubitschek foi um...\n')
pergunta7 = Perguntas('Em qual ano o musico "Matuê" lançou o albúm "Maquina do Tempo"?\n')
pergunta8 = Perguntas('Qual destes seriados de TV, é famoso por apresentar\n um mundo pós apocaliptico, e cercado de zumbis?\n')
pergunta9 = Perguntas('Qual o valor arredondado de π(PI)\n')
pergunta10 = Perguntas('Qual mitologia apresenta "Horus" como um deus?\n')
pergunta11 = Perguntas('Em que ano foi lançado o filme "Pulp Fiction"?\n')
pergunta12 = Perguntas('Qual é o maior país da América do Sul em área?\n')
pergunta13 = Perguntas('Quem escreveu "Cem Anos de Solidão"?\n')
pergunta14 = Perguntas('Qual é a fórmula química do sal de cozinha?\n')
pergunta15 = Perguntas('Qual foi o primeiro país a conceder o direito de voto às mulheres?\n')
pergunta16 = Perguntas('Qual é a capital da Noruega?\n')
pergunta17 = Perguntas('Qual cientista é conhecido como o "pai da genética moderna"?\n')
pergunta18 = Perguntas('Em que país está localizada a cidade de Machu Picchu?\n')
pergunta19 = Perguntas('Qual é a unidade de medida da frequência?\n')
pergunta20 = Perguntas('Quem pintou "A Noite Estrelada"?\n')
pergunta21 = Perguntas('Qual é o maior oceano do mundo?\n')
pergunta22 = Perguntas('Quem foi o primeiro presidente dos Estados Unidos?\n')
pergunta23 = Perguntas('Em que ano caiu o Muro de Berlim?\n')
pergunta24 = Perguntas('Qual é o país com a maior população do mundo?\n')
pergunta25 = Perguntas('Quem escreveu "Romeu e Julieta"?\n')
pergunta26 = Perguntas('Qual é o maior planeta do Sistema Solar?\n')
pergunta27 = Perguntas('Qual é o idioma oficial do Egito?\n')
pergunta28 = Perguntas('Quem inventou a lâmpada incandescente?\n')
pergunta29 = Perguntas('Em que continente está localizado o Deserto do Saara?\n')
pergunta30 = Perguntas('Qual é a capital do Canadá?\n')

# FUNÇÃO PARA EXIBIR AS ALTERNATIVAS

def questao1():
    print('a)', q1.a1)
    print('b)', q1.a2)
    print('c)', q1.a3)
    print('d)', q1.a4)

def questao2():
    print('a)', q2.a1)
    print('b)', q2.a2)
    print('c)', q2.a3)
    print('d)', q2.a4)

def questao3():
    print('a)', q3.a1)
    print('b)', q3.a2)
    print('c)', q3.a3)
    print('d)', q3.a4)

def questao4():
    print('a)', q4.a1)
    print('b)', q4.a2)
    print('c)', q4.a3)
    print('d)', q4.a4)

def questao5():
    print('a)', q5.a1)
    print('b)', q5.a2)
    print('c)', q5.a3)
    print('d)', q5.a4)

def questao6():
    print('a)', q6.a1)
    print('b)', q6.a2)
    print('c)', q6.a3)
    print('d)', q6.a4)

def questao7():
    print('a)', q7.a1)
    print('b)', q7.a2)
    print('c)', q7.a3)
    print('d)', q7.a4)

def questao8():
    print('a)', q8.a1)
    print('b)', q8.a2)
    print('c)', q8.a3)
    print('d)', q8.a4)

def questao9():
    print('a)', q9.a1)
    print('b)', q9.a2)
    print('c)', q9.a3)
    print('d)', q9.a4)

def questao10():
    print('a)', q10.a1)
    print('b)', q10.a2)
    print('c)', q10.a3)
    print('d)', q10.a4)

def questao11():
    print('a)', q11.a1)
    print('b)', q11.a2)
    print('c)', q11.a3)
    print('d)', q11.a4)

def questao12():
    print('a)', q12.a1)
    print('b)', q12.a2)
    print('c)', q12.a3)
    print('d)', q12.a4)

def questao13():
    print('a)', q13.a1)
    print('b)', q13.a2)
    print('c)', q13.a3)
    print('d)', q13.a4)

def questao14():
    print('a)', q14.a1)
    print('b)', q14.a2)
    print('c)', q14.a3)
    print('d)', q14.a4)

def questao15():
    print('a)', q15.a1)
    print('b)', q15.a2)
    print('c)', q15.a3)
    print('d)', q15.a4)

def questao16():
    print('a)', q16.a1)
    print('b)', q16.a2)
    print('c)', q16.a3)
    print('d)', q16.a4)

def questao17():
    print('a)', q17.a1)
    print('b)', q17.a2)
    print('c)', q17.a3)
    print('d)', q17.a4)

def questao18():
    print('a)', q18.a1)
    print('b)', q18.a2)
    print('c)', q18.a3)
    print('d)', q18.a4)

def questao19():
    print('a)', q19.a1)
    print('b)', q19.a2)
    print('c)', q19.a3)
    print('d)', q19.a4)

def questao20():
    print('a)', q20.a1)
    print('b)', q20.a2)
    print('c)', q20.a3)
    print('d)', q20.a4)

def questao21():
    print('a)', q21.a1)
    print('b)', q21.a2)
    print('c)', q21.a3)
    print('d)', q21.a4)

def questao22():
    print('a)', q22.a1)
    print('b)', q22.a2)
    print('c)', q22.a3)
    print('d)', q22.a4)

def questao23():
    print('a)', q23.a1)
    print('b)', q23.a2)
    print('c)', q23.a3)
    print('d)', q23.a4)

def questao24():
    print('a)', q24.a1)
    print('b)', q24.a2)
    print('c)', q24.a3)
    print('d)', q24.a4)

def questao25():
    print('a)', q25.a1)
    print('b)', q25.a2)
    print('c)', q25.a3)
    print('d)', q25.a4)

def questao26():
    print('a)', q26.a1)
    print('b)', q26.a2)
    print('c)', q26.a3)
    print('d)', q26.a4)

def questao27():
    print('a)', q27.a1)
    print('b)', q27.a2)
    print('c)', q27.a3)
    print('d)', q27.a4)

def questao28():
    print('a)', q28.a1)
    print('b)', q28.a2)
    print('c)', q28.a3)
    print('d)', q28.a4)

def questao29():
    print('a)', q29.a1)
    print('b)', q29.a2)
    print('c)', q29.a3)
    print('d)', q29.a4)

def questao30():
    print('a)', q30.a1)
    print('b)', q30.a2)
    print('c)', q30.a3)
    print('d)', q30.a4)
