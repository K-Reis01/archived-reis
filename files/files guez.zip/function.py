from colorama import init, Fore

init()

pts = True
pontuacao = []

def score():
    pontos = pontuacao
    if pts is True:
        pontos += '1'
        print('Score =', len(pontuacao))

def info_score():
    print('Score =',str(len(pontuacao)))

def result():
    if len(pontuacao) > 15:
        print(Fore.GREEN + 'Parabens, você acertou mais de 50% das questões!!!')
        print('Você fez',str(len(pontuacao)),'pontos.')
    elif len(pontuacao) <= 14:
        print(Fore.YELLOW + 'Poxa, sua pontuação poderia ter sido melhor... Que tal tentar de novo?')
        print('Você fez',str(len(pontuacao)),'pontos.')
