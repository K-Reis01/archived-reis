from quest import quest10, quest9, quest8, quest7, quest6, quest5, quest4, quest3, quest2, quest1
from quest import pergunta1, pergunta2, pergunta3, pergunta4, pergunta5, pergunta6, pergunta7, pergunta8, pergunta9, pergunta10
from quest import questao1, questao2, questao3, questao4, questao5, questao6, questao7, questao8, questao9, questao10
from quest import quest11, quest12, quest13, quest14, quest15, quest16, quest17, quest18, quest19, quest20
from quest import pergunta11, pergunta12, pergunta13, pergunta14, pergunta15, pergunta16, pergunta17, pergunta18, pergunta19, pergunta20
from quest import questao11, questao12, questao13, questao14, questao15, questao16, questao17, questao18, questao19, questao20
from quest import quest21, quest22, quest23, quest24, quest25, quest26, quest27, quest28, quest29, quest30
from quest import pergunta21, pergunta22, pergunta23, pergunta24, pergunta25, pergunta26, pergunta27, pergunta28, pergunta29, pergunta30
from quest import questao21, questao22, questao23, questao24, questao25, questao26, questao27, questao28, questao29, questao30
from colorama import init, Fore
from function import score, info_score, result

init()

print(Fore.LIGHTBLUE_EX + '\n        Seja Bem Vindo ao Guez')
print('O Guez é um quiz, de conhecimentos gerais')
print(Fore.RED + '\nRegras')
print(Fore.RED + '* Não vale pesquisar')
print(Fore.RED + '* Não vale tentativas de burla, seja elas qual forem')
print(Fore.RED + '* A cada pergunta respondida corretamente será acumulado um ponto,\n   caso erre nenhum ponto será adcionado')
print(Fore.RED + '* Ao final do jogo sua pontuação total será informada!')
print('\n')
print(Fore.WHITE + 'Para iniciar o jogo precione "enter"...')
input('- ')
print('Para selecionar sua resposta, digite a letra que corresponde a alternativa correta\n(apenas letras minusculas)\n')

# PERGUNTAS E ALTERNATIVAS
# Pergunta 1

print(Fore.WHITE + '_________________________________________________')
print(pergunta1.pergunta)
questao1()
pg1 = input('- ')
if pg1 == quest1.c:
    print(Fore.GREEN + '\nParabens, você acertou!')
    score()
else:
    print(Fore.RED + '\nOps, a resposta correta era a letra',quest1.c)
    info_score()

#**************************************************************
# Pergunta 2

print('\n')
print(Fore.WHITE + '______________________________________')
print(pergunta2.pergunta)
questao2()
pg2 = input('- ')
if pg2 == quest2.d:
    print(Fore.GREEN + '\nParabens, você acertou!')
    score()
else:
    print(Fore.RED + '\nOps, a resposta correta era a letra',quest2.d)
    info_score()

#**************************************************************
# Pergunta 3

print('\n')
print(Fore.WHITE + '_________________________________________________')
print(pergunta3.pergunta)
questao3()
pg3 = input('- ')
if pg3 == quest3.b:
    print(Fore.GREEN + '\nParabens, você acertou!')
    score()
else:
    print(Fore.RED + '\nOps, a resposta correta era a letra',quest3.b)
    info_score()

#**************************************************************
# Pergunta 4

print('\n')
print(Fore.WHITE + '________________________________________________________')
print(pergunta4.pergunta)
questao4()
pg4 = input('- ')
if pg4 == quest4.b:
    print(Fore.GREEN + '\nParabens, você acertou!')
    score()
else:
    print(Fore.RED + '\nOps, a resposta correta era a letra',quest4.b)
    info_score()

#**************************************************************
# Pergunta 5

print('\n')
print(Fore.WHITE + '______________________________________________________________')
print(pergunta5.pergunta)
questao5()
pg5 = input('- ')
if pg5 == quest5.a:
    print(Fore.GREEN + '\nParabens, você acertou!')
    score()
else:
    print(Fore.RED + '\nOps, a resposta correta era a letra',quest5.a)
    info_score()

#**************************************************************
# Pergunta 6

print('\n')
print(Fore.WHITE + '______________________________________________________________')
print(pergunta6.pergunta)
questao6()
pg6 = input('- ')
if pg6 == quest6.d:
    print(Fore.GREEN + '\nParabens, você acertou!')
    score()
else:
    print(Fore.RED + '\nOps, a resposta correta era a letra',quest6.d)
    info_score()

#**************************************************************
# Pergunta 7

print('\n')
print(Fore.WHITE + '______________________________________________________________')
print(pergunta7.pergunta)
questao7()
pg7 = input('- ')
if pg7 == quest7.a:
    print(Fore.GREEN + '\nParabens, você acertou!')
    score()
else:
    print(Fore.RED + '\nOps, a resposta correta era a letra',quest7.a)
    info_score()

#**************************************************************
# Pergunta 8

print('\n')
print(Fore.WHITE + '______________________________________________________________')
print(pergunta8.pergunta)
questao8()
pg8 = input('- ')
if pg8 == quest8.c:
    print(Fore.GREEN + '\nParabens, você acertou!')
    score()
else:
    print(Fore.RED + '\nOps, a resposta correta era a letra',quest8.c)
    info_score()

#**************************************************************
# Pergunta 9

print('\n')
print(Fore.WHITE + '______________________________________________________________')
print(pergunta9.pergunta)
questao9()
pg9 = input('- ')
if pg9 == quest9.b:
    print(Fore.GREEN + '\nParabens, você acertou!')
    score()
else:
    print(Fore.RED + '\nOps, a resposta correta era a letra',quest9.b)
    info_score()

#**************************************************************
# Pergunta 10

print('\n')
print(Fore.WHITE + '______________________________________________________________')
print(pergunta10.pergunta)
questao10()
pg10 = input('- ')
if pg10 == quest10.d:
    print(Fore.GREEN + '\nParabens, você acertou!')
    score()
else:
    print(Fore.RED + '\nOps, a resposta correta era a letra',quest10.d)
    info_score()

print('\nParabens, agora as perguntas serão mais dificeis!')

#**************************************************************
# Pergunta 11

print('\n')
print(Fore.WHITE + '______________________________________________________________')
print(pergunta11.pergunta)
questao11()
pg11 = input('- ')

if pg11 == quest11.c:
    print(Fore.GREEN + '\nParabens, você acertou!')
    score()
else:
    print(Fore.RED + '\nOps, a resposta correta era a letra', quest11.c)
    info_score()

#**************************************************************
# Pergunta 12

print('\n')
print(Fore.WHITE + '______________________________________________________________')
print(pergunta12.pergunta)
questao12()
pg12 = input('- ')

if pg12 == quest12.b:
    print(Fore.GREEN + '\nParabens, você acertou!')
    score()
else:
    print(Fore.RED + '\nOps, a resposta correta era a letra', quest12.b)
    info_score()

print('\n')
print(Fore.WHITE + '______________________________________________________________')
print(pergunta13.pergunta)
questao13()
pg13 = input('- ')

if pg13 == quest13.b:
    print(Fore.GREEN + '\nParabens, você acertou!')
    score()
else:
    print(Fore.RED + '\nOps, a resposta correta era a letra', quest13.b)
    info_score()

# Continue a sequência até 30

print('\n')
print(Fore.WHITE + '______________________________________________________________')
print(pergunta14.pergunta)
questao14()
pg14 = input('- ')

if pg14 == quest14.d:
    print(Fore.GREEN + '\nParabens, você acertou!')
    score()
else:
    print(Fore.RED + '\nOps, a resposta correta era a letra', quest14.d)
    info_score()

print('\n')
print(Fore.WHITE + '______________________________________________________________')
print(pergunta15.pergunta)
questao15()
pg15 = input('- ')

if pg15 == quest15.b:
    print(Fore.GREEN + '\nParabens, você acertou!')
    score()
else:
    print(Fore.RED + '\nOps, a resposta correta era a letra', quest15.b)
    info_score()

print('\n')
print(Fore.WHITE + '______________________________________________________________')
print(pergunta16.pergunta)
questao16()
pg16 = input('- ')

if pg16 == quest16.d:
    print(Fore.GREEN + '\nParabens, você acertou!')
    score()
else:
    print(Fore.RED + '\nOps, a resposta correta era a letra', quest16.d)
    info_score()

print('\n')
print(Fore.WHITE + '______________________________________________________________')
print(pergunta17.pergunta)
questao17()
pg17 = input('- ')

if pg17 == quest17.a:
    print(Fore.GREEN + '\nParabens, você acertou!')
    score()
else:
    print(Fore.RED + '\nOps, a resposta correta era a letra', quest17.a)
    info_score()

print('\n')
print(Fore.WHITE + '______________________________________________________________')
print(pergunta18.pergunta)
questao18()
pg18 = input('- ')

if pg18 == quest18.c:
    print(Fore.GREEN + '\nParabens, você acertou!')
    score()
else:
    print(Fore.RED + '\nOps, a resposta correta era a letra', quest18.c)
    info_score()

print('\n')
print(Fore.WHITE + '______________________________________________________________')
print(pergunta19.pergunta)
questao19()
pg19 = input('- ')

if pg19 == quest19.d:
    print(Fore.GREEN + '\nParabens, você acertou!')
    score()
else:
    print(Fore.RED + '\nOps, a resposta correta era a letra', quest19.d)
    info_score()

print('\n')
print(Fore.WHITE + '______________________________________________________________')
print(pergunta20.pergunta)
questao20()
pg20 = input('- ')

if pg20 == quest20.c:
    print(Fore.GREEN + '\nParabens, você acertou!')
    score()
else:
    print(Fore.RED + '\nOps, a resposta correta era a letra', quest20.c)
    info_score()

print('\n')
print(Fore.WHITE + '______________________________________________________________')
print(pergunta21.pergunta)
questao21()
pg21 = input('- ')

if pg21 == quest21.c:
    print(Fore.GREEN + '\nParabens, você acertou!')
    score()
else:
    print(Fore.RED + '\nOps, a resposta correta era a letra', quest21.c)
    info_score()

print('\n')
print(Fore.WHITE + '______________________________________________________________')
print(pergunta22.pergunta)
questao22()
pg22 = input('- ')

if pg22 == quest22.a:
    print(Fore.GREEN + '\nParabens, você acertou!')
    score()
else:
    print(Fore.RED + '\nOps, a resposta correta era a letra', quest22.a)
    info_score()

print('\n')
print(Fore.WHITE + '______________________________________________________________')
print(pergunta23.pergunta)
questao23()
pg23 = input('- ')

if pg23 == quest23.b:
    print(Fore.GREEN + '\nParabens, você acertou!')
    score()
else:
    print(Fore.RED + '\nOps, a resposta correta era a letra', quest23.b)
    info_score()

print('\n')
print(Fore.WHITE + '______________________________________________________________')
print(pergunta24.pergunta)
questao24()
pg24 = input('- ')

if pg24 == quest24.a:
    print(Fore.GREEN + '\nParabens, você acertou!')
    score()
else:
    print(Fore.RED + '\nOps, a resposta correta era a letra', quest24.a)
    info_score()

print('\n')
print(Fore.WHITE + '______________________________________________________________')
print(pergunta25.pergunta)
questao25()
pg25 = input('- ')

if pg25 == quest25.b:
    print(Fore.GREEN + '\nParabens, você acertou!')
    score()
else:
    print(Fore.RED + '\nOps, a resposta correta era a letra', quest25.b)
    info_score()

print('\n')
print(Fore.WHITE + '______________________________________________________________')
print(pergunta26.pergunta)
questao26()
pg26 = input('- ')

if pg26 == quest26.c:
    print(Fore.GREEN + '\nParabens, você acertou!')
    score()
else:
    print(Fore.RED + '\nOps, a resposta correta era a letra', quest26.c)
    info_score()

print('\n')
print(Fore.WHITE + '______________________________________________________________')
print(pergunta27.pergunta)
questao27()
pg27 = input('- ')

if pg27 == quest27.d:
    print(Fore.GREEN + '\nParabens, você acertou!')
    score()
else:
    print(Fore.RED + '\nOps, a resposta correta era a letra', quest27.d)
    info_score()

print('\n')
print(Fore.WHITE + '______________________________________________________________')
print(pergunta28.pergunta)
questao28()
pg28 = input('- ')

if pg28 == quest28.b:
    print(Fore.GREEN + '\nParabens, você acertou!')
    score()
else:
    print(Fore.RED + '\nOps, a resposta correta era a letra', quest28.b)
    info_score()

print('\n')
print(Fore.WHITE + '______________________________________________________________')
print(pergunta29.pergunta)
questao29()
pg29 = input('- ')

if pg29 == quest29.d:
    print(Fore.GREEN + '\nParabens, você acertou!')
    score()
else:
    print(Fore.RED + '\nOps, a resposta correta era a letra', quest29.d)
    info_score()

print('\n')
print(Fore.WHITE + '______________________________________________________________')
print(pergunta30.pergunta)
questao30()
pg30 = input('- ')

if pg30 == quest30.b:
    print(Fore.GREEN + '\nParabens, você acertou!')
    score()
else:
    print(Fore.RED + '\nOps, a resposta correta era a letra', quest30.b)
    info_score()

print('\n')
result()

print('\n')
print(Fore.WHITE + 'Obrigado Por jogar, em breve mais niveis serão adcionados!')
like = input('Gostou do nosso jogo?("s" ou "n") - ')

if like == 's':
    print('Ficamos felizes que você tenha gostado, seu feedback nos ajuda a continuar!')
elif like == 'n':
    print('Poxa, que pena que não gostou, tentaremos melhorar o que for possivel!')
else:
    print('Não conseguimos entender sua resposta, mas esperamos que tenha gostado e aproveitado ao maximo!')

print('\n')
print(input('Precione a tecla "Enter" para fechar...'))