pts = True
pontuacao = []

def score():
    pontos = pontuacao
    if pts is True:
        pontos += '1'
        print('Score =', len(pontuacao))

def info_score():
    print('Score =',str(len(pontuacao)))
