from quest import quest10, quest9, quest8, quest7, quest6, quest5, quest4, quest3, quest2, quest1
from quest import pergunta1, pergunta2, pergunta3, pergunta4, pergunta5, pergunta6, pergunta7, pergunta8, pergunta9, pergunta10
from quest import questao1, questao2, questao3, questao4, questao5, questao6, questao7, questao8, questao9, questao10
from function import score, info_score

print('\nSeja Bem Vindo ao Guez')
print('O Guez é um quiz, de conhecimentos gerais')
print('\nRegras')
print('* Não vale pesquisar')
print('* Não vale tentativas de burla, seja elas qual forem')
print('* A cada pergunta respondida corretamente será acumulado um ponto,\n   caso erre nenhum ponto será adcionado')
print('* Ao final do jogo sua pontuação total será informada!')
print('\n')
print('Para iniciar o jogo precione "enter"...')
input('- ')
print('Para selecionar sua resposta, digite a letra que corresponde a alternativa correta\n(apenas letras minusculas)\n')

# PERGUNTAS E ALTERNATIVAS
# Pergunta 1

print('_________________________________________________')
print(pergunta1.pergunta)
questao1()
pg1 = input('- ')
if pg1 == quest1.c:
    print('Parabens, você acertou!')
    score()
else:
    print('Ops, a resposta correta era a letra',quest1.c)
    info_score()

#**************************************************************
# Pergunta 2

print('\n')
print('______________________________________')
print(pergunta2.pergunta)
questao2()
pg2 = input('- ')
if pg2 == quest2.d:
    print('Parabens, você acertou!')
    score()
else:
    print('Ops, a resposta correta era a letra',quest2.d)
    info_score()

#**************************************************************
# Pergunta 3

print('\n')
print('_________________________________________________')
print(pergunta3.pergunta)
questao3()
pg3 = input('- ')
if pg3 == quest3.b:
    print('Parabens, você acertou!')
    score()
else:
    print('Ops, a resposta correta era a letra',quest3.b)
    info_score()

#**************************************************************
# Pergunta 4

print('\n')
print('________________________________________________________')
print(pergunta4.pergunta)
questao4()
pg4 = input('- ')
if pg4 == quest4.b:
    print('Parabens, você acertou!')
    score()
else:
    print('Ops, a resposta correta era a letra',quest4.b)
    info_score()

#**************************************************************
# Pergunta 5

print('\n')
print('______________________________________________________________')
print(pergunta5.pergunta)
questao5()
pg5 = input('- ')
if pg5 == quest5.a:
    print('Parabens, você acertou!')
    score()
else:
    print('Ops, a resposta correta era a letra',quest5.a)
    info_score()

#**************************************************************
# Pergunta 6

print('\n')
print('______________________________________________________________')
print(pergunta6.pergunta)
questao6()
pg6 = input('- ')
if pg6 == quest6.d:
    print('Parabens, você acertou!')
    score()
else:
    print('Ops, a resposta correta era a letra',quest6.d)
    info_score()

#**************************************************************
# Pergunta 7

print('\n')
print('______________________________________________________________')
print(pergunta7.pergunta)
questao7()
pg7 = input('- ')
if pg7 == quest7.a:
    print('Parabens, você acertou!')
    score()
else:
    print('Ops, a resposta correta era a letra',quest7.a)
    info_score()

#**************************************************************
# Pergunta 8

print('\n')
print('______________________________________________________________')
print(pergunta8.pergunta)
questao8()
pg8 = input('- ')
if pg8 == quest8.c:
    print('Parabens, você acertou!')
    score()
else:
    print('Ops, a resposta correta era a letra',quest8.c)
    info_score()

#**************************************************************
# Pergunta 9

print('\n')
print('______________________________________________________________')
print(pergunta9.pergunta)
questao9()
pg9 = input('- ')
if pg9 == quest9.b:
    print('Parabens, você acertou!')
    score()
else:
    print('Ops, a resposta correta era a letra',quest9.b)
    info_score()

#**************************************************************
# Pergunta 10

print('\n')
print('______________________________________________________________')
print(pergunta10.pergunta)
questao10()
pg10 = input('- ')
if pg10 == quest10.d:
    print('Parabens, você acertou!')
    score()
else:
    print('Ops, a resposta correta era a letra',quest10.d)
    info_score()

print('\n')
print('Obrigado Por jogar, em breve mais niveis serão adcionados!')
like = input('Gostou do nosso jogo?("s" ou "n") - ')

if like == 's':
    print('Ficamos felizes que você tenha gostado, seu feedback nos ajuda a continuar!')
elif like == 'n':
    print('Poxa, que pena que não gostou, tentaremos melhorar o que for possivel!')
else:
    print('Não conseguimos entender sua resposta, mas esperamos que tenha gostado e aproveitado ao maximo!')

print('\n')
print(input('Precione a tecla "Enter" para fechar...'))