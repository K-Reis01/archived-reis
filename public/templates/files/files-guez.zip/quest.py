class Quest:
    def __init__(self, a, b, c, d):
        self.a = a
        self.b = b
        self.c = c
        self.d = d


class See:
    def __init__(self, a1, a2, a3, a4):
        self.a1 = a1
        self.a2 = a2
        self.a3 = a3
        self.a4 = a4


class Perguntas:
    def __init__(self, pergunta):
        self.pergunta = pergunta


# ALTERNATIVAS DAS PERGUNTAS
quest1 = Quest('a','b','c','d')
quest2 = Quest('a','b','c','d')
quest3 = Quest('a','b','c','d')
quest4 = Quest('a','b','c','d')
quest5 = Quest('a','b','c','d')
quest6 = Quest('a','b','c','d')
quest7 = Quest('a','b','c','d')
quest8 = Quest('a','b','c','d')
quest9 = Quest('a','b','c','d')
quest10 = Quest('a','b','c','d')

q1 = See('preto, amarelo e vermelho','branco, azul, verde e rosa','branco, azul, verde e amarelo', 'branco, azul, dourado, verde')
q2 = See('New York','Los Angeles','Nevada','Washington')
q3 = See('Os Simpsons','Bob Esponja','Procurando o Nemo','Futurama')
q4 = See('Ordem e Progresso','Independecia ou Morte','Mãe tem café?','Independencia a Patria Amada')
q5 = See('Apollo 11','Sputnik 1','Starship','Vostok 1')
q6 = See('Cantor Norte Americano','Poeta Europeu','Mafioso Italiano','Presidente do brasil')
q7 = See('2020','2019','2021','2024')
q8 = See('Family Guy','Todo Mundo em Panico','The Walking Dead','Gotham')
q9 = See('2,0132','3,14','3,85','0,11')
q10 = See('Mitologia Grega','Mitologia Nordica','Mitologia Brasileira','Mitologia Egipicia')


# FUNÇÃO PARA EXIBIR AS PERGUNTAS

pergunta1 = Perguntas('Quais cores presentes na bandeira do Brasil?\n')
pergunta2 = Perguntas('Qual a capital dos Estados Unidos?\n')
pergunta3 = Perguntas('Em qual desenho animado o personagem principal\ntem como melhor amigo uma estrela do mar?\n')
pergunta4 = Perguntas('O que Dom Pedro I gritou as margens do rio Ipiranga?\n')
pergunta5 = Perguntas('Qual nome da primeira nave espacial tripulada a pousar na lua?\n')
pergunta6 = Perguntas('Juscelino Kubitschek foi um...\n')
pergunta7 = Perguntas('Em qual ano o musico "Matuê" lançou o albúm "Maquina do Tempo"?\n')
pergunta8 = Perguntas('Qual destes seriados de TV, é famoso por apresentar\n um mundo pós apocaliptico, e cercado de zumbis?\n')
pergunta9 = Perguntas('Qual o valor arredondado de π(PI)\n')
pergunta10 = Perguntas('Qual mitologia apresenta "Horus" como um deus?\n')


# FUNÇÃO PARA EXIBIR AS ALTERNATIVAS

def questao1():
    print('a)', q1.a1)
    print('b)', q1.a2)
    print('c)', q1.a3)
    print('d)', q1.a4)

def questao2():
    print('a)', q2.a1)
    print('b)', q2.a2)
    print('c)', q2.a3)
    print('d)', q2.a4)

def questao3():
    print('a)', q3.a1)
    print('b)', q3.a2)
    print('c)', q3.a3)
    print('d)', q3.a4)

def questao4():
    print('a)', q4.a1)
    print('b)', q4.a2)
    print('c)', q4.a3)
    print('d)', q4.a4)

def questao5():
    print('a)', q5.a1)
    print('b)', q5.a2)
    print('c)', q5.a3)
    print('d)', q5.a4)

def questao6():
    print('a)', q6.a1)
    print('b)', q6.a2)
    print('c)', q6.a3)
    print('d)', q6.a4)

def questao7():
    print('a)', q7.a1)
    print('b)', q7.a2)
    print('c)', q7.a3)
    print('d)', q7.a4)

def questao8():
    print('a)', q8.a1)
    print('b)', q8.a2)
    print('c)', q8.a3)
    print('d)', q8.a4)

def questao9():
    print('a)', q9.a1)
    print('b)', q9.a2)
    print('c)', q9.a3)
    print('d)', q9.a4)

def questao10():
    print('a)', q10.a1)
    print('b)', q10.a2)
    print('c)', q10.a3)
    print('d)', q10.a4)